import json,random,statistics,sys,torch
from pathlib import Path
from torch.nn import functional as F
from cid.stage_c import load_base_for_stage_c,load_display_adapter,freeze_for_stage_c,load_stage_c_examples,make_display_batch,frozen_thought_rollout
from cid.model.policy import ILLaDAContextTensorizer
from cid.accelerator import wrap_torch_autocast
p=Path(__file__).parent
torch.manual_seed(1337)
a,tok,enc=load_base_for_stage_c(p/'model',checkpoint_kind='release',model='',device=torch.device('cuda'),dtype=torch.bfloat16)
mod=load_display_adapter(sys.argv[1],a)
a.eval()
tensorizer=ILLaDAContextTensorizer(a,tok,text_encoder=enc)
fwd=wrap_torch_autocast(torch,a,device_type='cuda',dtype=torch.bfloat16)
rows=load_stage_c_examples(p/'data/nemotron-v3-pilot-4000.jsonl')
random.Random(20261023).shuffle(rows)
rows=rows[3000:]
res=[]
for i,example in enumerate(rows):
 if len(res)>=64:break
 try:
  answer=enc.tokenize(example.answer,add_special_tokens=False)
  prompt=enc.tokenize(example.prompt,add_special_tokens=True)
  length=int(answer.shape[1]);canv=max(a.config.display_canvas_tokens,length+1)
  if length<1 or length+1>min(384,a.config.max_display_tokens) or a.config.max_thought_slots+int(prompt.shape[1])+canv>a.max_position_embeddings:continue
  torchgen=torch.Generator(device='cuda').manual_seed(91000+len(res))
  thought=frozen_thought_rollout(a,tensorizer,example.prompt,steps=2,forward_model=fwd)
  batch,targets=make_display_batch(tensorizer,thought,example,generator=torchgen,maximum_tokens=384,rollout_probability=.8,continuation_tokens=16)
  mask=targets!=-100
  with torch.no_grad():
   mod.enabled=False
   baseline=fwd(batch).display_logits.float()
   mod.enabled=True
   adapted=fwd(batch).display_logits.float()
   gold=targets[mask]
   old=baseline[mask];new=adapted[mask]
   oldloss=F.cross_entropy(old,gold)
   newloss=F.cross_entropy(new,gold)
   oldacc=(old.argmax(-1)==gold).float().mean().item()
   newacc=(new.argmax(-1)==gold).float().mean().item()
   eospos=torch.nonzero(batch.display_ids[0]==a.eos_token_id,as_tuple=False).flatten()
   if len(eospos):
    pos=int(eospos[0]);eos_target=int(targets[0,pos]);
    if eos_target!=-100:
     oe=F.softmax(baseline[0,pos],dim=-1)[a.eos_token_id].item()
     ne=F.softmax(adapted[0,pos],dim=-1)[a.eos_token_id].item()
    else:oe=ne=None
   else:oe=ne=None
   res.append(dict(index=i,length=length,valid=int(mask.sum()),base_loss=oldloss.item(),stagec_loss=newloss.item(),base_acc=oldacc,stagec_acc=newacc,base_eosprob=oe,stagec_eosprob=ne))
   if len(res)%16==0:print('progress',len(res),'nll',round(statistics.mean(x['base_loss'] for x in res),2),round(statistics.mean(x['stagec_loss'] for x in res),2),flush=True)
 except (ValueError,RuntimeError) as exc:
  if 'exceeds' in str(exc):continue
  raise
out=sys.argv[2]
Path(out).write_text(json.dumps(res,indent=2))
print('SUMMARY','n',len(res),'mean_base_nll',statistics.mean(x['base_loss'] for x in res),'mean_stagec_nll',statistics.mean(x['stagec_loss'] for x in res),'base_acc',statistics.mean(x['base_acc'] for x in res),'stagec_acc',statistics.mean(x['stagec_acc'] for x in res))
