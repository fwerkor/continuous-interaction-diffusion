import argparse
import asyncio
import json
import time
from pathlib import Path
import torch
from cid.stage_c import load_base_for_stage_c, load_display_adapter
from cid.model.policy import ILLaDAContextTensorizer, ILLaDANeuralPolicy, ILLaDANeuralPolicyConfig
from cid.runtime import CIDRuntime, RuntimeConfig, SourceRegistry
from cid.state import CognitiveField, DisplayCanvas
from cid.accelerator import wrap_torch_autocast

ROOT=Path(__file__).resolve().parent
SAMPLES=[
 ('identity_zh','你好，请介绍一下你自己。',None),
 ('greeting_en','Hello! How are you today?',None),
 ('linux_explain','Please explain what Linux is in two or three sentences.',None),
 ('sum_12_19','What is 12 plus 19? Give a brief answer.','31'),
 ('hardware_compare','Describe the differences between RAM and SSD in a few sentences.',None),
 ('greeting_generate','Write a friendly two-sentence greeting.',None),
 ('sum_2_2','What is 2 + 2? Reply with the number.','4'),
 ('capital_france','What is the capital of France?','Paris'),
 ('days_week','How many days are there in a week?','7'),
 ('third_planet','What is the third planet from the Sun?','Earth'),
 ('api_definition','What is an API? Explain it in one sentence.',None),
 ('python_definition','What is Python, the programming language?',None),
 ('loop_explain','Explain a for loop in one sentence.',None),
 ('network_explain','What does HTTP stand for?','Hypertext Transfer Protocol'),
 ('linux_kernel','Is Linux open source? Answer yes or no.','Yes'),
 ('cloud_intro','Explain cloud computing in two simple sentences.',None),
 ('short_story','Write a single sentence about a rainy morning.',None),
 ('translation_zh','Translate "good morning" into Chinese.','早上好'),
 ('list_three','Name three common programming languages.',None),
 ('binary_1','What does the binary number 101 equal in decimal?','5'),
]
parser=argparse.ArgumentParser()
parser.add_argument('--adapter',default='')
parser.add_argument('--output',required=True)
parser.add_argument('--max-steps',type=int,default=16)
parser.add_argument('--canvas',type=int,default=256)
parser.add_argument('--adapter-scale',type=float,default=1.0)
args=parser.parse_args()
torch.manual_seed(42)
model,tok,encoder=load_base_for_stage_c(ROOT/'model',checkpoint_kind='release',model='',device=torch.device('cuda:0'),dtype=torch.bfloat16)
if args.adapter:
  module=load_display_adapter(args.adapter,model)
  module.alpha *= args.adapter_scale
model.eval()
tensorizer=ILLaDAContextTensorizer(model,tok,text_encoder=encoder)
forward=wrap_torch_autocast(torch,model,device_type='cuda',dtype=torch.bfloat16)
result=[]
for i,(case,prompt,expected) in enumerate(SAMPLES):
  policy=ILLaDANeuralPolicy(model,tensorizer,config=ILLaDANeuralPolicyConfig(denoising_steps=8,seed=1729+i),forward_model=forward)
  runtime=CIDRuntime(SourceRegistry(),RuntimeConfig(max_steps=args.max_steps,max_wall_time_s=30))
  canvas=DisplayCanvas.initial_unresolved(length=args.canvas,mask_token_id=model.mask_token_id,eos_token_id=model.eos_token_id)
  t=time.time()
  out=asyncio.run(runtime.run(policy,thought=CognitiveField.empty(model.config.max_thought_slots,model.d_model),display=canvas,prompt='User:\n'+prompt))
  answer=tok.decode([token for token in out.display.visible_token_ids if token!=model.mask_token_id],skip_special_tokens=True)
  row={'case':case,'prompt':prompt,'answer':answer,'expected':expected,'tokens':out.display.realized_length,'steps':out.steps,'converged':out.converged,'elapsed':round(time.time()-t,2)}
  result.append(row)
  print(json.dumps(row,ensure_ascii=False),flush=True)
Path(args.output).write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf8')
