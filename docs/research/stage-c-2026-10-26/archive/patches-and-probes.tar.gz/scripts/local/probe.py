import argparse, asyncio, json, time, torch
from pathlib import Path
from cid.stage_c import load_base_for_stage_c,load_display_adapter
from cid.model.policy import ILLaDAContextTensorizer,ILLaDANeuralPolicy,ILLaDANeuralPolicyConfig
from cid.runtime import CIDRuntime,RuntimeConfig,SourceRegistry
from cid.state import CognitiveField,DisplayCanvas
from cid.accelerator import wrap_torch_autocast
p=argparse.ArgumentParser();p.add_argument('--adapter',default='');p.add_argument('--output',required=True);a=p.parse_args()
root=Path('<local-home>/cid-stage-c-retry')
model,tok,encoder=load_base_for_stage_c(root/'model',checkpoint_kind='release',model='',device=torch.device('cuda:0'),dtype=torch.bfloat16)
if a.adapter:load_display_adapter(a.adapter,model)
model.eval()
tensorizer=ILLaDAContextTensorizer(model,tok,text_encoder=encoder)
forward=wrap_torch_autocast(torch,model,device_type='cuda',dtype=torch.bfloat16)
prompts=['User:\n你好，请介绍一下你自己。','User:\nHello! How are you today?','User:\nPlease explain what Linux is in two or three sentences.','User:\nWhat is 12 plus 19? Give a brief answer.','User:\nDescribe the differences between RAM and SSD in a few sentences.','User:\nWrite a friendly two-sentence greeting.']
result=[]
for i,prompt in enumerate(prompts):
  policy=ILLaDANeuralPolicy(model,tensorizer,config=ILLaDANeuralPolicyConfig(denoising_steps=8,seed=1729+i),forward_model=forward)
  runtime=CIDRuntime(SourceRegistry(),RuntimeConfig(max_steps=16,max_wall_time_s=30))
  canvas=DisplayCanvas.initial_unresolved(length=256,mask_token_id=model.mask_token_id,eos_token_id=model.eos_token_id)
  t=time.time()
  out=asyncio.run(runtime.run(policy,thought=CognitiveField.empty(model.config.max_thought_slots,model.d_model),display=canvas,prompt=prompt))
  answer=tok.decode([token for token in out.display.visible_token_ids if token!=model.mask_token_id],skip_special_tokens=True)
  row={'question':prompt,'answer':answer,'tokens':out.display.realized_length,'steps':out.steps,'converged':out.converged,'elapsed':round(time.time()-t,2)}
  result.append(row);print(json.dumps(row,ensure_ascii=False),flush=True)
Path(a.output).write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf8')
